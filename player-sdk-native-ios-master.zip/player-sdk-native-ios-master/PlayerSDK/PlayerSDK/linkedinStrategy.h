//
//  LinkedInStrtegy.h
//  KALTURAPlayerSDK
//
//  Created by Nissim Pardo on 2/19/15.
//  Copyright (c) 2015 Kaltura. All rights reserved.
//

#import "GooglePlusStrategy.h"

@interface LinkedinStrategy :GoogleplusStrategy

@end
