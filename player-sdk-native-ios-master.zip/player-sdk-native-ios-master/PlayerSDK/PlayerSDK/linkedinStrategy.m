//
//  LinkedInStrtegy.m
//  KALTURAPlayerSDK
//
//  Created by Nissim Pardo on 2/19/15.
//  Copyright (c) 2015 Kaltura. All rights reserved.
//

#import "LinkedinStrategy.h"

@implementation LinkedinStrategy

@end
