//
//  TwitterStrategy.m
//  KALTURAPlayerSDK
//
//  Created by Nissim Pardo on 11/5/14.
//  Copyright (c) 2014 Kaltura. All rights reserved.
//

#import "TwitterStrategy.h"

@implementation TwitterStrategy
- (NSString *)composeType {
    return SLServiceTypeTwitter;
}

@end
