//
//  KPWebKitBroeserViewController.h
//  KALTURAPlayerSDK
//
//  Created by Nissim Pardo on 11/27/14.
//  Copyright (c) 2014 Kaltura. All rights reserved.
//

#import "KPBrowserViewController.h"


@interface KPWebKitBrowserViewController : KPBrowserViewController

@end
