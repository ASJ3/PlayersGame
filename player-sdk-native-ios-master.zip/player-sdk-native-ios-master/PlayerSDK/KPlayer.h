//
//  KPlayer.h
//  KALTURAPlayerSDK
//
//  Created by Nissim Pardo on 3/12/15.
//  Copyright (c) 2015 Kaltura. All rights reserved.
//

#import "KPlayerController.h"


@interface KPlayer : AVPlayer <KPlayer>

@end
